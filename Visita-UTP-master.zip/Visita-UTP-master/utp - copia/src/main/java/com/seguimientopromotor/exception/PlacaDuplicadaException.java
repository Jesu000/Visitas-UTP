package com.seguimientopromotor.exception;

public class PlacaDuplicadaException extends RuntimeException {
    public PlacaDuplicadaException(String placa) {
        super("La placa ya está registrada: " + placa);
    }
}
