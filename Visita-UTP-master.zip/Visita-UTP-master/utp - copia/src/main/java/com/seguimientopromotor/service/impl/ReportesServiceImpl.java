package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.response.ReportesDto;
import com.seguimientopromotor.dto.response.ResumenPromotorDto;
import com.seguimientopromotor.dto.response.VisitaDto;
import com.seguimientopromotor.model.Visita;
import com.seguimientopromotor.service.AlumnoService;
import com.seguimientopromotor.service.ReportesService;
import com.seguimientopromotor.service.VisitaService;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ReportesServiceImpl implements ReportesService {

    private final VisitaService visitaService;
    private final AlumnoService alumnoService;

    public ReportesServiceImpl(VisitaService visitaService, AlumnoService alumnoService) {
        this.visitaService = visitaService;
        this.alumnoService = alumnoService;
    }

    @Override
    public ReportesDto generarReporte() {
        List<VisitaDto> visitas = visitaService.findAll();

        long realizadas = visitas.stream()
                .filter(v -> v.getEstado() == Visita.EstadoVisita.REALIZADA
                          || v.getEstado() == Visita.EstadoVisita.VERIFICADA)
                .count();
        long pendientes = visitas.stream()
                .filter(v -> v.getEstado() == Visita.EstadoVisita.PENDIENTE).count();
        long canceladas = visitas.stream()
                .filter(v -> v.getEstado() == Visita.EstadoVisita.CANCELADA).count();
        long instituciones = visitas.stream()
                .map(VisitaDto::getColegioDestino).filter(Objects::nonNull).distinct().count();
        long evidencias = visitas.stream()
                .filter(v -> v.getEvidenciaFoto() != null && !v.getEvidenciaFoto().isBlank()).count();

        Map<String, long[]> conteo = new LinkedHashMap<>();
        Map<String, Set<String>> institMap = new LinkedHashMap<>();

        for (VisitaDto v : visitas) {
            String nombre = (v.getEmpleadoNombre() != null) ? v.getEmpleadoNombre() : "Sin asignar";
            conteo.computeIfAbsent(nombre, k -> new long[]{0, 0});
            institMap.computeIfAbsent(nombre, k -> new LinkedHashSet<>());
            conteo.get(nombre)[0]++;
            if (v.getColegioDestino() != null) institMap.get(nombre).add(v.getColegioDestino());
            if (v.getEvidenciaFoto() != null && !v.getEvidenciaFoto().isBlank())
                conteo.get(nombre)[1]++;
        }

        List<ResumenPromotorDto> resumen = conteo.entrySet().stream()
                .map(e -> new ResumenPromotorDto(
                        e.getKey(),
                        e.getValue()[0],
                        new ArrayList<>(institMap.get(e.getKey())),
                        e.getValue()[1]))
                .toList();

        return new ReportesDto(visitas, realizadas, pendientes, canceladas,
                instituciones, evidencias, alumnoService.count(), resumen);
    }
}
