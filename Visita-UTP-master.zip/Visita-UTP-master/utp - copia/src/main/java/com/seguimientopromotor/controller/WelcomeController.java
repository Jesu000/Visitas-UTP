package com.seguimientopromotor.controller;

import com.seguimientopromotor.dto.request.AlumnoRequest;
import com.seguimientopromotor.dto.request.ColegioRequest;
import com.seguimientopromotor.dto.request.TransporteRequest;
import com.seguimientopromotor.dto.request.UsuarioRequest;
import com.seguimientopromotor.dto.request.VisitaRequest;
import com.seguimientopromotor.exception.AutoEliminacionException;
import com.seguimientopromotor.exception.EmailDuplicadoException;
import com.seguimientopromotor.exception.PlacaDuplicadaException;
import com.seguimientopromotor.model.Alumno;
import com.seguimientopromotor.model.Colegio;
import com.seguimientopromotor.model.Transporte;
import com.seguimientopromotor.model.Usuario;
import com.seguimientopromotor.model.Visita;
import com.seguimientopromotor.service.AlumnoService;
import com.seguimientopromotor.service.ColegioService;
import com.seguimientopromotor.service.ReportesService;
import com.seguimientopromotor.service.TransporteService;
import com.seguimientopromotor.service.UbicacionGpsService;
import com.seguimientopromotor.service.UsuarioService;
import com.seguimientopromotor.service.VisitaService;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class WelcomeController {

    private final UsuarioService usuarioService;
    private final VisitaService visitaService;
    private final ColegioService colegioService;
    private final UbicacionGpsService ubicacionService;
    private final TransporteService transporteService;
    private final AlumnoService alumnoService;
    private final ReportesService reportesService;

    public WelcomeController(UsuarioService usuarioService, VisitaService visitaService,
                             ColegioService colegioService, UbicacionGpsService ubicacionService,
                             TransporteService transporteService, AlumnoService alumnoService,
                             ReportesService reportesService) {

        this.usuarioService = usuarioService;
        this.visitaService = visitaService;
        this.colegioService = colegioService;
        this.ubicacionService = ubicacionService;
        this.transporteService = transporteService;
        this.alumnoService = alumnoService;
        this.reportesService = reportesService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, Authentication auth) {
        boolean supervisor = isSupervisor(auth);
        if (supervisor) {
            model.addAttribute("totalUsuarios", usuarioService.count());
            model.addAttribute("activos",       usuarioService.countByEstado(Usuario.EstadoUsuario.ACTIVO));
            model.addAttribute("inactivos",     usuarioService.countByEstado(Usuario.EstadoUsuario.INACTIVO));
            model.addAttribute("suspendidos",   usuarioService.countByEstado(Usuario.EstadoUsuario.SUSPENDIDO));
            model.addAttribute("realizadas",    visitaService.countByEstado(Visita.EstadoVisita.REALIZADA));
            model.addAttribute("pendientes",    visitaService.countByEstado(Visita.EstadoVisita.PENDIENTE));
            model.addAttribute("canceladas",    visitaService.countByEstado(Visita.EstadoVisita.CANCELADA));
            model.addAttribute("evidencias",    visitaService.findTop3Recent());
        } else {
            String email = auth.getName();
            model.addAttribute("totalUsuarios", 0);
            model.addAttribute("activos",       0);
            model.addAttribute("inactivos",     0);
            model.addAttribute("suspendidos",   0);
            model.addAttribute("realizadas",    visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.REALIZADA, email));
            model.addAttribute("pendientes",    visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.PENDIENTE, email));
            model.addAttribute("canceladas",    visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.CANCELADA, email));
            model.addAttribute("evidencias",    visitaService.findTop3RecentByPromotor(email));
        }
        model.addAttribute("paginaActiva", "dashboard");
        return "dashboard";
    }

    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        model.addAttribute("usuarios",      usuarioService.findAll());
        model.addAttribute("totalUsuarios", usuarioService.count());
        model.addAttribute("activos",       usuarioService.countByEstado(Usuario.EstadoUsuario.ACTIVO));
        model.addAttribute("inactivos",     usuarioService.countByEstado(Usuario.EstadoUsuario.INACTIVO));
        model.addAttribute("suspendidos",   usuarioService.countByEstado(Usuario.EstadoUsuario.SUSPENDIDO));
        model.addAttribute("paginaActiva",  "usuarios");
        return "usuarios";
    }

    @GetMapping("/registrar-visita")
    public String registrarVisita(Model model, Authentication auth) {
        VisitaRequest visita = new VisitaRequest();
        if (!isSupervisor(auth)) {
            // El promotor registra siempre en su propio nombre.
            // empleadoId lleva el id del usuario: el service lo resuelve a la entidad real.
            usuarioService.findByEmail(auth.getName()).ifPresent(u -> {
                visita.setEmpleadoNombre(u.getNombre());
                visita.setEmpleadoId(String.valueOf(u.getId()));
            });
        }
        model.addAttribute("visita",       visita);
        model.addAttribute("empleados",    usuarioService.findByEstado(Usuario.EstadoUsuario.ACTIVO));
        model.addAttribute("colegios",     colegioService.findByEstado(Colegio.EstadoColegio.ACTIVO));
        model.addAttribute("paginaActiva", "registrar-visita");
        return "registrar-visita";
    }

    @PostMapping("/registrar-visita")
    public String guardarVisita(@ModelAttribute VisitaRequest request) {
        visitaService.guardar(request);
        return "redirect:/dashboard?visitaGuardada=true";
    }

    @GetMapping("/reportes")
    public String reportes(Model model) {
        var data = reportesService.generarReporte();
        model.addAttribute("visitas",          data.getVisitas());
        model.addAttribute("realizadas",        data.getRealizadas());
        model.addAttribute("pendientes",        data.getPendientes());
        model.addAttribute("canceladas",        data.getCanceladas());
        model.addAttribute("instituciones",     data.getInstituciones());
        model.addAttribute("evidencias",        data.getEvidencias());
        model.addAttribute("totalAlumnos",      data.getTotalAlumnos());
        model.addAttribute("resumenPromotores", data.getResumenPromotores());
        model.addAttribute("paginaActiva",      "reportes");
        return "reportes";
    }

    @GetMapping("/historial")
    public String historial() {
        return "redirect:/registro-visitas";
    }

    // ===== REGISTRO VISITAS + TRANSPORTE (COMPLETAR) =====

    @GetMapping("/registro-visitas")
    public String registroVisitas(Model model, Authentication auth) {
        Sort sort = Sort.by(Sort.Direction.DESC, "fechaProgramada", "horaEstimada");
        if (isSupervisor(auth)) {
            model.addAttribute("visitas",    visitaService.findAll(sort));
            model.addAttribute("pendientes", visitaService.countByEstado(Visita.EstadoVisita.PENDIENTE));
            model.addAttribute("realizadas", visitaService.countByEstado(Visita.EstadoVisita.REALIZADA));
            model.addAttribute("canceladas", visitaService.countByEstado(Visita.EstadoVisita.CANCELADA));
        } else {
            String email = auth.getName();
            model.addAttribute("visitas",    visitaService.findByPromotor(email, sort));
            model.addAttribute("pendientes", visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.PENDIENTE, email));
            model.addAttribute("realizadas", visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.REALIZADA, email));
            model.addAttribute("canceladas", visitaService.countByEstadoAndPromotor(Visita.EstadoVisita.CANCELADA, email));
        }
        model.addAttribute("colegios",    colegioService.findAll());
        model.addAttribute("paginaActiva", "registro-visitas");
        return "registro-visitas";
    }

    @PostMapping("/registro-visitas/{id}/editar")
    public String editarVisita(@PathVariable Long id, @ModelAttribute VisitaRequest request) {
        visitaService.actualizar(id, request);
        return "redirect:/registro-visitas?actualizado=true";
    }

    @PostMapping("/registro-visitas/{id}/completar")
    public String completarVisita(@PathVariable("id") Long id) {
        visitaService.completarVisita(id);
        return "redirect:/registro-visitas?completado=true";
    }


    @GetMapping("/perfil")
    public String perfil(Model model, Authentication auth) {

        usuarioService.findByEmail(auth.getName())
                .ifPresent(u -> model.addAttribute("usuario", u));
        model.addAttribute("paginaActiva", "perfil");
        return "perfil";
    }

    @GetMapping("/seguimiento-gps")
    public String seguimientoGps(Model model) {
        model.addAttribute("empleados",    usuarioService.findByEstado(Usuario.EstadoUsuario.ACTIVO));
        model.addAttribute("ubicaciones",  ubicacionService.findAll());
        model.addAttribute("paginaActiva", "seguimiento-gps");
        return "seguimiento-gps";
    }

    // ===== TRANSPORTE =====

    @GetMapping("/transporte")
    public String transporte(Model model) {
        var stats = transporteService.getStats();
        model.addAttribute("transportes",     stats.getTransportes());
        model.addAttribute("disponibles",     stats.getDisponibles());
        model.addAttribute("enRuta",          stats.getEnRuta());
        model.addAttribute("mantenimiento",   stats.getMantenimiento());
        model.addAttribute("nuevoTransporte", new TransporteRequest());
        model.addAttribute("empleados",       usuarioService.findByEstado(Usuario.EstadoUsuario.ACTIVO));
        model.addAttribute("paginaActiva",    "transporte");
        return "transporte";
    }

    @PostMapping("/transporte")
    public String guardarTransporte(@ModelAttribute TransporteRequest request) {
        try {
            transporteService.guardar(request);
            return "redirect:/transporte?guardado=true";
        } catch (PlacaDuplicadaException e) {
            return "redirect:/transporte?error=placa";
        }
    }

    @PostMapping("/transporte/{id}/eliminar")
    public String eliminarTransporte(@PathVariable Long id) {
        transporteService.deleteById(id);
        return "redirect:/transporte?eliminado=true";
    }

    @PostMapping("/transporte/{id}/estado")
    public String cambiarEstadoTransporte(@PathVariable Long id, @RequestParam String estado) {
        transporteService.cambiarEstado(id, Transporte.EstadoTransporte.valueOf(estado));
        return "redirect:/transporte?actualizado=true";
    }

    // ===== INSTITUCIONES =====

    @GetMapping("/instituciones")
    public String instituciones(Model model) {
        model.addAttribute("colegios",     colegioService.findAll());
        model.addAttribute("nuevoColegio", new ColegioRequest());
        model.addAttribute("paginaActiva", "instituciones");
        return "instituciones";
    }

    @PostMapping("/instituciones")
    public String guardarInstitucion(@ModelAttribute ColegioRequest request) {
        colegioService.guardar(request);
        return "redirect:/instituciones?guardado=true";
    }

    @PostMapping("/instituciones/{id}/eliminar")
    public String eliminarInstitucion(@PathVariable Long id) {
        colegioService.deleteById(id);
        return "redirect:/instituciones?eliminado=true";
    }

    // ===== ALUMNOS =====

    @GetMapping("/alumnos")
    public String alumnos(Model model, Authentication auth) {
        Sort sort = Sort.by(Sort.Direction.DESC, "fechaRegistro");
        if (isSupervisor(auth)) {
            model.addAttribute("alumnos",      alumnoService.findAll(sort));
            model.addAttribute("totalAlumnos", alumnoService.count());
            model.addAttribute("interesAlto",  alumnoService.countByNivelInteres(Alumno.NivelInteres.ALTO));
            model.addAttribute("interesMedio", alumnoService.countByNivelInteres(Alumno.NivelInteres.MEDIO));
            model.addAttribute("interesBajo",  alumnoService.countByNivelInteres(Alumno.NivelInteres.BAJO));
        } else {
            String email = auth.getName();
            model.addAttribute("alumnos",      alumnoService.findByPromotor(email, sort));
            model.addAttribute("totalAlumnos", alumnoService.countByPromotor(email));
            model.addAttribute("interesAlto",  alumnoService.countByNivelInteresAndPromotor(Alumno.NivelInteres.ALTO, email));
            model.addAttribute("interesMedio", alumnoService.countByNivelInteresAndPromotor(Alumno.NivelInteres.MEDIO, email));
            model.addAttribute("interesBajo",  alumnoService.countByNivelInteresAndPromotor(Alumno.NivelInteres.BAJO, email));
        }
        model.addAttribute("nuevoAlumno",  new AlumnoRequest());
        model.addAttribute("colegios",     colegioService.findByEstado(Colegio.EstadoColegio.ACTIVO));
        model.addAttribute("paginaActiva", "alumnos");
        return "alumnos";
    }

    @PostMapping("/alumnos")
    public String guardarAlumno(@ModelAttribute AlumnoRequest request, Authentication auth) {
        alumnoService.guardar(request, auth.getName());
        return "redirect:/alumnos?guardado=true";
    }

    @PostMapping("/alumnos/{id}/editar")
    public String editarAlumno(@PathVariable Long id, @ModelAttribute AlumnoRequest request) {
        alumnoService.actualizar(id, request);
        return "redirect:/alumnos?actualizado=true";
    }

    @PostMapping("/alumnos/{id}/eliminar")
    public String eliminarAlumno(@PathVariable Long id) {
        alumnoService.deleteById(id);
        return "redirect:/alumnos?eliminado=true";
    }

    // ===== CRUD USUARIOS =====

    @PostMapping("/usuarios")
    public String crearUsuario(@ModelAttribute UsuarioRequest request) {
        try {
            usuarioService.crear(request);
            return "redirect:/usuarios?guardado=true";
        } catch (EmailDuplicadoException e) {
            return "redirect:/usuarios?error=email";
        }
    }

    @PostMapping("/usuarios/{id}/editar")
    public String editarUsuario(@PathVariable Long id, @ModelAttribute UsuarioRequest request) {
        try {
            usuarioService.actualizar(id, request);
            return "redirect:/usuarios?actualizado=true";
        } catch (EmailDuplicadoException e) {
            return "redirect:/usuarios?error=email";
        }
    }

    @PostMapping("/usuarios/{id}/eliminar")
    public String eliminarUsuario(@PathVariable Long id, Authentication auth) {
        try {
            usuarioService.deleteById(id, auth.getName());
            return "redirect:/usuarios?eliminado=true";
        } catch (AutoEliminacionException e) {
            return "redirect:/usuarios?error=propio";
        }
    }

    @PostMapping("/usuarios/{id}/estado")
    public String cambiarEstadoUsuario(@PathVariable Long id, @RequestParam String estado) {
        usuarioService.cambiarEstado(id, Usuario.EstadoUsuario.valueOf(estado));
        return "redirect:/usuarios?actualizado=true";
    }

    // ===== CAMBIO DE CONTRASEÑA =====

    @PostMapping("/perfil/password")
    public String cambiarPassword(@RequestParam String passwordActual,
                                  @RequestParam String passwordNueva,
                                  @RequestParam String passwordConfirma,
                                  Authentication auth) {
        if (!usuarioService.verificarPassword(auth.getName(), passwordActual))
            return "redirect:/perfil?error=actual";
        if (!passwordNueva.equals(passwordConfirma))
            return "redirect:/perfil?error=confirmacion";
        if (passwordNueva.length() < 3)
            return "redirect:/perfil?error=corta";
        usuarioService.cambiarPassword(auth.getName(), passwordNueva);
        return "redirect:/perfil?passwordCambiada=true";
    }

    @GetMapping("/test")
    @ResponseBody
    public String test() {
        return "FUNCIONA";
    }

    // ──────────────────────────────────
    //  Helpers de rol
    // ──────────────────────────────────

    private boolean isSupervisor(Authentication auth) {
        return auth != null && auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_SUPERVISOR"));
    }
}
