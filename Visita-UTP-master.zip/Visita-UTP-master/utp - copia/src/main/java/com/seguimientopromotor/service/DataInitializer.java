package com.seguimientopromotor.service;

import com.seguimientopromotor.model.Alumno;
import com.seguimientopromotor.model.Colegio;
import com.seguimientopromotor.model.Transporte;
import com.seguimientopromotor.model.UbicacionGps;
import com.seguimientopromotor.model.Usuario;
import com.seguimientopromotor.model.Visita;
import com.seguimientopromotor.repository.AlumnoRepository;
import com.seguimientopromotor.repository.ColegioRepository;
import com.seguimientopromotor.repository.TransporteRepository;
import com.seguimientopromotor.repository.UbicacionGpsRepository;
import com.seguimientopromotor.repository.UsuarioRepository;
import com.seguimientopromotor.repository.VisitaRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepo;
    private final VisitaRepository visitaRepo;
    private final ColegioRepository colegioRepo;
    private final UbicacionGpsRepository ubicacionRepo;
    private final TransporteRepository transporteRepo;
    private final AlumnoRepository alumnoRepo;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepo, VisitaRepository visitaRepo,
                           ColegioRepository colegioRepo, UbicacionGpsRepository ubicacionRepo,
                           TransporteRepository transporteRepo, AlumnoRepository alumnoRepo,
                           PasswordEncoder passwordEncoder) {
        this.usuarioRepo = usuarioRepo;
        this.visitaRepo = visitaRepo;
        this.colegioRepo = colegioRepo;
        this.ubicacionRepo = ubicacionRepo;
        this.transporteRepo = transporteRepo;
        this.alumnoRepo = alumnoRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        // Con ddl-auto=update los datos persisten entre reinicios: solo sembrar si la BD está vacía
        if (usuarioRepo.count() > 0) return;

        Usuario pablo  = crearUsuario("Pablo de Tarso",    "p.detarso@utp.edu.pe", "123", "San Borja",   "PROMOTOR",   Usuario.EstadoUsuario.ACTIVO,      12, "E30001");
        Usuario pedro  = crearUsuario("Pedro Gomez",       "p.gomez@utp.edu.pe",   "123", "San Isidro",  "PROMOTOR",   Usuario.EstadoUsuario.ACTIVO,       9, "E30002");
        Usuario juan   = crearUsuario("Juan Amado",        "j.amado@utp.edu.pe",   "123", "Surco",       "PROMOTOR",   Usuario.EstadoUsuario.ACTIVO,       7, "E30003");
        Usuario maria  = crearUsuario("Maria Quispe",      "m.quispe@utp.edu.pe",  "123", "La Molina",   "PROMOTOR",   Usuario.EstadoUsuario.ACTIVO,      15, "E30004");
        Usuario carlos = crearUsuario("Carlos Flores",     "c.flores@utp.edu.pe",  "123", "Barranco",    "PROMOTOR",   Usuario.EstadoUsuario.ACTIVO,       0, "E30005");
        crearUsuario("Lucia Tito",        "l.tito@utp.edu.pe",    "123", "Lima Norte",  "PROMOTOR",   Usuario.EstadoUsuario.SUSPENDIDO,   4, "E30006");
        crearUsuario("Alexander Carrero", "a.carrero@utp.edu.pe", "123", "San Isidro",  "SUPERVISOR", Usuario.EstadoUsuario.ACTIVO,       0, "E30314");

        crearVisita("Colegio Salvador", LocalDate.of(2026, 5, 10), LocalTime.of(10, 30),
                "Convocatoria Presencial", pablo, Visita.EstadoVisita.VERIFICADA, "foto1.png");
        crearVisita("Colegio Cristo",   LocalDate.of(2026, 5, 10), LocalTime.of(11, 31),
                "Convocatoria Presencial", pedro, Visita.EstadoVisita.VERIFICADA, "foto2.png");
        crearVisita("Colegio UTP",      LocalDate.of(2026, 5, 10), LocalTime.of(9, 12),
                "Virtual",               juan,  Visita.EstadoVisita.PENDIENTE,  "foto3.png");

        crearColegio("Colegio Cristo Rey",   "Av. Aviación 2405",        "San Borja",  "Marta Salinas",    "01-4751234");
        crearColegio("Colegio San Salvador", "Jr. Las Begonias 441",     "San Isidro", "Jorge Paredes",    "01-4419876");
        crearColegio("Colegio La Molina",    "Av. La Molina 1180",       "La Molina",  "Rosa Cárdenas",    "01-3685521");
        crearColegio("Colegio Barranco",     "Av. Grau 810",             "Barranco",   "Luis Mendoza",     "01-2476690");
        crearColegio("Colegio Sur",          "Av. Caminos del Inca 350", "Surco",      "Ana Villanueva",   "01-2718845");
        crearColegio("Institución UTP",      "Av. Arequipa 265",         "Lima",       "Oficina Admisión", "01-3159600");

        crearUbicacion(pablo,  -12.1067, -76.9990, "San Borja",  UbicacionGps.EstadoSenal.EN_CAMPO);
        crearUbicacion(pedro,  -12.0976, -77.0365, "San Isidro", UbicacionGps.EstadoSenal.EN_CAMPO);
        crearUbicacion(juan,   -12.1356, -76.9930, "Surco",      UbicacionGps.EstadoSenal.RETRASO);
        crearUbicacion(maria,  -12.0867, -76.9120, "La Molina",  UbicacionGps.EstadoSenal.EN_CAMPO);
        crearUbicacion(carlos, -12.1410, -77.0210, "Barranco",   UbicacionGps.EstadoSenal.SIN_GPS);

        crearTransporte("Movilidad", "ABC-123", "Roberto Díaz",   4,  "San Borja - Miraflores", "Pablo de Tarso", Transporte.EstadoTransporte.EN_RUTA);
        crearTransporte("Van",       "DEF-456", "Miguel Torres",  8,  "San Isidro - Lince",     "Pedro Gomez",    Transporte.EstadoTransporte.EN_RUTA);
        crearTransporte("Movilidad", "GHI-789", "Sandra Rojas",   4,  "Surco - Chorrillos",     null,             Transporte.EstadoTransporte.DISPONIBLE);
        crearTransporte("Bus",       "JKL-012", "Hugo Castillo", 20,  "Lima Norte",             null,             Transporte.EstadoTransporte.MANTENIMIENTO);

        crearAlumno("Diego",    "Salazar Quinto", "74125836", "987111222", "diego.salazar@gmail.com", "5to A", "Ing. de Sistemas",  "Colegio Cristo Rey",   pablo, Alumno.NivelInteres.ALTO);
        crearAlumno("Valeria",  "Mamani Rojas",   "75236947", "987333444", "vale.mamani@gmail.com",   "5to B", "Ing. Industrial",   "Colegio Cristo Rey",   pablo, Alumno.NivelInteres.MEDIO);
        crearAlumno("Bruno",    "Castro Vega",    "76347058", "987555666", "bruno.castro@gmail.com",  "4to A", "Arquitectura",      "Colegio San Salvador", pedro, Alumno.NivelInteres.ALTO);
        crearAlumno("Camila",   "Huamán Torres",  "77458169", "987777888", "cami.huaman@gmail.com",   "5to A", "Adm. de Empresas",  "Colegio San Salvador", pedro, Alumno.NivelInteres.BAJO);
        crearAlumno("Sebastián","Paredes Luna",   "78569270", "987999000", "seba.paredes@gmail.com",  "5to C", "Ing. de Software",  "Colegio La Molina",    maria, Alumno.NivelInteres.ALTO);
    }

    private Usuario crearUsuario(String nombre, String email, String password, String zona,
                                 String rol, Usuario.EstadoUsuario estado, int visitas, String codigo) {
        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(password));
        u.setZona(zona);
        u.setRol(rol);
        u.setEstado(estado);
        u.setVisitas(visitas);
        u.setCodigo(codigo);
        return usuarioRepo.save(u);
    }

    private void crearVisita(String colegio, LocalDate fecha, LocalTime hora,
                             String tipo, Usuario empleado, Visita.EstadoVisita estado, String foto) {
        Visita v = new Visita();
        v.setColegioDestino(colegio);
        v.setFechaProgramada(fecha);
        v.setHoraEstimada(hora);
        v.setTipoVisita(tipo);
        v.setEmpleado(empleado);
        v.setEstado(estado);
        v.setEvidenciaFoto(foto);
        visitaRepo.save(v);
    }

    private void crearColegio(String nombre, String direccion, String distrito,
                              String contacto, String telefono) {
        Colegio c = new Colegio();
        c.setNombre(nombre);
        c.setDireccion(direccion);
        c.setDistrito(distrito);
        c.setNombreContacto(contacto);
        c.setTelefono(telefono);
        c.setEstado(Colegio.EstadoColegio.ACTIVO);
        colegioRepo.save(c);
    }

    private void crearUbicacion(Usuario usuario, double latitud, double longitud,
                                String zona, UbicacionGps.EstadoSenal estadoSenal) {
        UbicacionGps u = new UbicacionGps();
        u.setUsuario(usuario);
        u.setLatitud(latitud);
        u.setLongitud(longitud);
        u.setZona(zona);
        u.setFechaHora(LocalDateTime.now());
        u.setEstadoSenal(estadoSenal);
        ubicacionRepo.save(u);
    }

    private void crearTransporte(String tipo, String placa, String conductor, int capacidad,
                                 String zonaCobertura, String empleadoAsignado,
                                 Transporte.EstadoTransporte estado) {
        Transporte t = new Transporte();
        t.setTipo(tipo);
        t.setPlaca(placa);
        t.setConductor(conductor);
        t.setCapacidad(capacidad);
        t.setZonaCobertura(zonaCobertura);
        t.setEmpleadoAsignado(empleadoAsignado);
        t.setEstado(estado);
        transporteRepo.save(t);
    }

    private void crearAlumno(String nombre, String apellido, String dni, String telefono,
                             String correo, String gradoSeccion, String carrera,
                             String colegio, Usuario promotor, Alumno.NivelInteres interes) {
        Alumno a = new Alumno();
        a.setNombre(nombre);
        a.setApellido(apellido);
        a.setDni(dni);
        a.setTelefono(telefono);
        a.setCorreo(correo);
        a.setGradoSeccion(gradoSeccion);
        a.setCarreraInteres(carrera);
        a.setColegioNombre(colegio);
        a.setPromotor(promotor);
        a.setFechaRegistro(LocalDate.now());
        a.setNivelInteres(interes);
        alumnoRepo.save(a);
    }
}
