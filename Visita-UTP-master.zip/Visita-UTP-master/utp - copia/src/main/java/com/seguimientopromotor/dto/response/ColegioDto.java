package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.Colegio;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColegioDto {
    private Long id;
    private String nombre;
    private String direccion;
    private String distrito;
    private String nombreContacto;
    private String telefono;
    private Colegio.EstadoColegio estado;
}
