package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.response.UbicacionGpsDto;

import java.util.List;

public interface UbicacionGpsService {
    List<UbicacionGpsDto> findAll();
}
