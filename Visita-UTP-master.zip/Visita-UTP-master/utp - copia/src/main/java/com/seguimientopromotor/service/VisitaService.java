package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.request.VisitaRequest;
import com.seguimientopromotor.dto.response.VisitaDto;
import com.seguimientopromotor.model.Visita;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface VisitaService {
    List<VisitaDto> findAll();
    List<VisitaDto> findAll(Sort sort);
    List<VisitaDto> findTop3Recent();
    long countByEstado(Visita.EstadoVisita estado);
    VisitaDto guardar(VisitaRequest request);
    void completarVisita(Long visitaId);
    VisitaDto actualizar(Long id, VisitaRequest request);

    // Métodos filtrados por promotor — identifica por email del usuario autenticado
    List<VisitaDto> findByPromotor(String email, Sort sort);
    long countByEstadoAndPromotor(Visita.EstadoVisita estado, String email);
    List<VisitaDto> findTop3RecentByPromotor(String email);
}
