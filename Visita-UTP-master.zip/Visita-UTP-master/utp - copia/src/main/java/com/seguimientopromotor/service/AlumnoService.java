package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.request.AlumnoRequest;
import com.seguimientopromotor.dto.response.AlumnoDto;
import com.seguimientopromotor.model.Alumno;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface AlumnoService {
    List<AlumnoDto> findAll(Sort sort);
    long count();
    long countByNivelInteres(Alumno.NivelInteres nivelInteres);
    AlumnoDto guardar(AlumnoRequest request, String promotorEmail);
    void deleteById(Long id);
    AlumnoDto actualizar(Long id, AlumnoRequest request);

    // Métodos filtrados por promotor — identifica por email del usuario autenticado
    List<AlumnoDto> findByPromotor(String email, Sort sort);
    long countByPromotor(String email);
    long countByNivelInteresAndPromotor(Alumno.NivelInteres nivel, String email);
}
