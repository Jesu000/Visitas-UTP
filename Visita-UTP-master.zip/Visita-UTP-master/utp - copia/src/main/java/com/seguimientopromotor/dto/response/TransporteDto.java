package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.Transporte;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransporteDto {
    private Long id;
    private String tipo;
    private String placa;
    private String conductor;
    private int capacidad;
    private String zonaCobertura;
    private String empleadoAsignado;
    private Transporte.EstadoTransporte estado;
}
