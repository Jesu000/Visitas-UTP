package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.request.UsuarioRequest;
import com.seguimientopromotor.dto.response.UsuarioDto;
import com.seguimientopromotor.exception.AutoEliminacionException;
import com.seguimientopromotor.exception.EmailDuplicadoException;
import com.seguimientopromotor.model.Usuario;
import com.seguimientopromotor.repository.UsuarioRepository;
import com.seguimientopromotor.service.UsuarioService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public List<UsuarioDto> findAll() {
        return usuarioRepository.findAll().stream().map(this::toDto).toList();
    }

    @Override
    public long count() {
        return usuarioRepository.count();
    }

    @Override
    public long countByEstado(Usuario.EstadoUsuario estado) {
        return usuarioRepository.countByEstado(estado);
    }

    @Override
    public List<UsuarioDto> findByEstado(Usuario.EstadoUsuario estado) {
        return usuarioRepository.findByEstado(estado).stream().map(this::toDto).toList();
    }

    @Override
    public Optional<UsuarioDto> findByEmail(String email) {
        return usuarioRepository.findByEmail(email).map(this::toDto);
    }

    @Override
    public Optional<UsuarioDto> findById(Long id) {
        return usuarioRepository.findById(id).map(this::toDto);
    }

    @Override
    public UsuarioDto crear(UsuarioRequest request) {
        if (usuarioRepository.findByEmail(request.getEmail()).isPresent())
            throw new EmailDuplicadoException(request.getEmail());
        Usuario u = new Usuario();
        u.setNombre(request.getNombre());
        u.setEmail(request.getEmail());
        String raw = (request.getPassword() != null && !request.getPassword().isBlank())
                ? request.getPassword() : "123";
        u.setPassword(passwordEncoder.encode(raw));
        u.setZona(request.getZona());
        u.setRol(request.getRol());
        u.setEstado(Usuario.EstadoUsuario.ACTIVO);
        Usuario guardado = usuarioRepository.save(u);
        // El código de empleado se deriva del id para garantizar unicidad (ej: E30008)
        guardado.setCodigo("E3" + String.format("%04d", guardado.getId()));
        return toDto(usuarioRepository.save(guardado));
    }

    @Override
    public UsuarioDto actualizar(Long id, UsuarioRequest request) {
        Usuario u = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado: " + id));
        // El email debe seguir siendo único entre los demás usuarios
        usuarioRepository.findByEmail(request.getEmail()).ifPresent(otro -> {
            if (!otro.getId().equals(id)) throw new EmailDuplicadoException(request.getEmail());
        });
        u.setNombre(request.getNombre());
        u.setEmail(request.getEmail());
        u.setZona(request.getZona());
        u.setRol(request.getRol());
        // La contraseña solo cambia si se escribió una nueva
        if (request.getPassword() != null && !request.getPassword().isBlank())
            u.setPassword(passwordEncoder.encode(request.getPassword()));
        return toDto(usuarioRepository.save(u));
    }

    @Override
    public void deleteById(Long id, String currentUserEmail) {
        usuarioRepository.findByEmail(currentUserEmail).ifPresent(current -> {
            if (current.getId().equals(id)) throw new AutoEliminacionException();
        });
        usuarioRepository.deleteById(id);
    }

    @Override
    public void cambiarEstado(Long id, Usuario.EstadoUsuario nuevoEstado) {
        usuarioRepository.findById(id).ifPresent(u -> {
            u.setEstado(nuevoEstado);
            usuarioRepository.save(u);
        });
    }

    @Override
    public boolean verificarPassword(String email, String passwordActual) {
        return usuarioRepository.findByEmail(email)
                .map(u -> passwordEncoder.matches(passwordActual, u.getPassword()))
                .orElse(false);
    }

    @Override
    public void cambiarPassword(String email, String passwordNueva) {
        usuarioRepository.findByEmail(email).ifPresent(u -> {
            u.setPassword(passwordEncoder.encode(passwordNueva));
            usuarioRepository.save(u);
        });
    }

    private UsuarioDto toDto(Usuario u) {
        return new UsuarioDto(u.getId(), u.getNombre(), u.getEmail(),
                u.getZona(), u.getRol(), u.getEstado(), u.getVisitas(), u.getCodigo());
    }
}
