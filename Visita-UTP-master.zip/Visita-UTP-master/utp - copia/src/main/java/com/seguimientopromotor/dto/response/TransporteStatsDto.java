package com.seguimientopromotor.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransporteStatsDto {
    private List<TransporteDto> transportes;
    private long disponibles;
    private long enRuta;
    private long mantenimiento;
}
