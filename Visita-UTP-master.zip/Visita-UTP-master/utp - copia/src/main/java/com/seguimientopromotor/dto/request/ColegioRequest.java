package com.seguimientopromotor.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColegioRequest {
    private String nombre;
    private String direccion;
    private String distrito;
    private String nombreContacto;
    private String telefono;
}
