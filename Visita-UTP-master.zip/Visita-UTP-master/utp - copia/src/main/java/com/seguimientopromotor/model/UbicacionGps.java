package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "ubicaciones_gps")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UbicacionGps {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    private double latitud;
    private double longitud;
    private String zona;
    private LocalDateTime fechaHora;

    @Enumerated(EnumType.STRING)
    private EstadoSenal estadoSenal;

    public enum EstadoSenal {
        EN_CAMPO, RETRASO, SIN_GPS, INACTIVO
    }
}
