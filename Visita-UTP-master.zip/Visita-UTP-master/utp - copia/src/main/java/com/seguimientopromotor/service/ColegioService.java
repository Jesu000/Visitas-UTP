package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.request.ColegioRequest;
import com.seguimientopromotor.dto.response.ColegioDto;
import com.seguimientopromotor.model.Colegio;

import java.util.List;

public interface ColegioService {
    List<ColegioDto> findAll();
    List<ColegioDto> findByEstado(Colegio.EstadoColegio estado);
    ColegioDto guardar(ColegioRequest request);
    void deleteById(Long id);
}
