package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.Visita;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitaDto {
    private Long id;
    private LocalDate fechaProgramada;
    private LocalTime horaEstimada;
    private String tipoVisita;
    private String colegioDestino;
    private String instrucciones;
    private String prioridad;
    private String empleadoNombre;
    private String empleadoId;
    private Visita.EstadoVisita estado;
    private String evidenciaFoto;
    private Long transporteId;

}
