package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "alumnos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Alumno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String apellido;
    private String dni;
    private String telefono;
    private String correo;
    private String gradoSeccion;       // ej: 5to A
    private String carreraInteres;     // carrera UTP de interés
    private String colegioNombre;      // institución donde se registró
    private LocalDate fechaRegistro;

    // Relación real con el promotor que lo registró (antes era texto suelto)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "promotor_id")
    private Usuario promotor;

    @Enumerated(EnumType.STRING)
    private NivelInteres nivelInteres;

    public enum NivelInteres {
        ALTO, MEDIO, BAJO
    }
}
