package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.request.VisitaRequest;
import com.seguimientopromotor.dto.response.VisitaDto;
import com.seguimientopromotor.model.Usuario;
import com.seguimientopromotor.model.Visita;
import com.seguimientopromotor.model.Colegio;
import com.seguimientopromotor.model.Transporte;
import com.seguimientopromotor.repository.ColegioRepository;
import com.seguimientopromotor.repository.TransporteRepository;
import com.seguimientopromotor.repository.UsuarioRepository;
import com.seguimientopromotor.repository.VisitaRepository;
import com.seguimientopromotor.service.VisitaService;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VisitaServiceImpl implements VisitaService {

    private final VisitaRepository visitaRepository;
    private final ColegioRepository colegioRepository;
    private final TransporteRepository transporteRepository;
    private final UsuarioRepository usuarioRepository;

    public VisitaServiceImpl(VisitaRepository visitaRepository,
                              ColegioRepository colegioRepository,
                              TransporteRepository transporteRepository,
                              UsuarioRepository usuarioRepository) {
        this.visitaRepository = visitaRepository;
        this.colegioRepository = colegioRepository;
        this.transporteRepository = transporteRepository;
        this.usuarioRepository = usuarioRepository;
    }


    @Override
    public List<VisitaDto> findAll() {
        return visitaRepository.findAll().stream().map(this::toDto).toList();
    }

    @Override
    public List<VisitaDto> findAll(Sort sort) {
        return visitaRepository.findAll(sort).stream().map(this::toDto).toList();
    }

    @Override
    public List<VisitaDto> findTop3Recent() {
        return visitaRepository.findTop3ByOrderByFechaProgramadaDesc().stream().map(this::toDto).toList();
    }

    @Override
    public long countByEstado(Visita.EstadoVisita estado) {
        return visitaRepository.countByEstado(estado);
    }

    @Override
    public VisitaDto guardar(VisitaRequest request) {
        Visita v = new Visita();
        v.setFechaProgramada(request.getFechaProgramada());
        v.setHoraEstimada(request.getHoraEstimada());
        v.setTipoVisita(request.getTipoVisita());
        v.setColegioDestino(request.getColegioDestino());
        v.setInstrucciones(request.getInstrucciones());
        v.setPrioridad(request.getPrioridad());
        v.setEmpleado(resolverEmpleado(request));
        v.setEstado(Visita.EstadoVisita.PENDIENTE);

        // === Integración natural: asignar transporte disponible de la zona y marcar EN_RUTA ===
        // request.getColegioDestino() llega desde el select como "nombre — distrito".
        // Pero la zona debe salir desde base de datos:
        // 1) extraemos el nombre del colegio antes del separador
        // 2) buscamos el Colegio para obtener su distrito
        // 3) buscamos un Transporte DISPOIBLE para ese distrito
        String colegioNombre = extraerNombreColegio(request.getColegioDestino());
        if (colegioNombre != null) {
            colegioRepository.findByNombre(colegioNombre).ifPresent(colegio -> {
                String distrito = colegio.getDistrito();
                transporteRepository.findFirstByZonaCoberturaContainingIgnoreCaseAndEstado(
                        distrito, Transporte.EstadoTransporte.DISPONIBLE
                ).ifPresent(t -> {
                    v.setTransporteId(t.getId());
                    // marcar vehículo en ruta
                    transporteRepository.findById(t.getId()).ifPresent(tx -> {
                        tx.setEstado(Transporte.EstadoTransporte.EN_RUTA);
                        transporteRepository.save(tx);
                    });
                });
            });
        }

        return toDto(visitaRepository.save(v));
    }

    @Override
    public void completarVisita(Long visitaId) {
        visitaRepository.findById(visitaId).ifPresent(v -> {
            v.setEstado(Visita.EstadoVisita.REALIZADA);
            visitaRepository.save(v);

            if (v.getTransporteId() != null) {
                transporteRepository.findById(v.getTransporteId()).ifPresent(t -> {
                    t.setEstado(Transporte.EstadoTransporte.DISPONIBLE);
                    transporteRepository.save(t);
                });
            }
        });
    }

    @Override
    public VisitaDto actualizar(Long id, VisitaRequest request) {
        return visitaRepository.findById(id).map(v -> {
            v.setFechaProgramada(request.getFechaProgramada());
            v.setHoraEstimada(request.getHoraEstimada());
            v.setTipoVisita(request.getTipoVisita());
            v.setColegioDestino(request.getColegioDestino());
            v.setInstrucciones(request.getInstrucciones());
            v.setPrioridad(request.getPrioridad());
            return toDto(visitaRepository.save(v));
        }).orElseThrow(() -> new RuntimeException("Visita no encontrada: " + id));
    }

    @Override
    public List<VisitaDto> findByPromotor(String email, Sort sort) {
        return visitaRepository.findByEmpleado_Email(email, sort).stream().map(this::toDto).toList();
    }

    @Override
    public long countByEstadoAndPromotor(Visita.EstadoVisita estado, String email) {
        return visitaRepository.countByEstadoAndEmpleado_Email(estado, email);
    }

    @Override
    public List<VisitaDto> findTop3RecentByPromotor(String email) {
        return visitaRepository.findTop3ByEmpleado_EmailOrderByFechaProgramadaDesc(email)
                .stream().map(this::toDto).toList();
    }

    /**
     * Resuelve la entidad Usuario del promotor asignado:
     * primero por id (lo que envía el formulario), como respaldo por nombre.
     */
    private Usuario resolverEmpleado(VisitaRequest request) {
        if (request.getEmpleadoId() != null && !request.getEmpleadoId().isBlank()) {
            try {
                Long usuarioId = Long.parseLong(request.getEmpleadoId().trim());
                Usuario u = usuarioRepository.findById(usuarioId).orElse(null);
                if (u != null) return u;
            } catch (NumberFormatException ignored) { /* puede llegar un código tipo E30001 */ }
        }
        if (request.getEmpleadoNombre() != null && !request.getEmpleadoNombre().isBlank())
            return usuarioRepository.findFirstByNombre(request.getEmpleadoNombre().trim()).orElse(null);
        return null;
    }

    private String extraerNombreColegio(String colegioDestino) {
        if (colegioDestino == null) return null;
        String s = colegioDestino.trim();
        if (s.isBlank()) return null;
        // Esperado: "Nombre — Distrito" (con guion largo). Si no existe separador, usamos todo.
        String[] parts = s.split("—", 2);
        if (parts.length > 0) {
            String name = parts[0].trim();
            return name.isBlank() ? null : name;
        }
        return null;
    }


    private VisitaDto toDto(Visita v) {
        // El DTO sigue exponiendo nombre/id como String para no romper las vistas
        String nombre = v.getEmpleado() != null ? v.getEmpleado().getNombre() : null;
        String codigo = v.getEmpleado() != null ? v.getEmpleado().getCodigo() : null;
        return new VisitaDto(v.getId(), v.getFechaProgramada(), v.getHoraEstimada(),
                v.getTipoVisita(), v.getColegioDestino(), v.getInstrucciones(),
                v.getPrioridad(), nombre, codigo,
                v.getEstado(), v.getEvidenciaFoto(), v.getTransporteId());
    }

}
