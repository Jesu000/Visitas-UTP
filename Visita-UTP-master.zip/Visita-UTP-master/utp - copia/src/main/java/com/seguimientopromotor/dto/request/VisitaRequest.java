package com.seguimientopromotor.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitaRequest {
    private LocalDate fechaProgramada;
    private LocalTime horaEstimada;
    private String tipoVisita;
    private String colegioDestino;
    private String instrucciones;
    private String prioridad;
    private String empleadoNombre;
    private String empleadoId;
}
