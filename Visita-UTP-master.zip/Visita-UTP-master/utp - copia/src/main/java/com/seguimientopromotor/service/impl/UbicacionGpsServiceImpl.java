package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.response.UbicacionGpsDto;
import com.seguimientopromotor.model.UbicacionGps;
import com.seguimientopromotor.repository.UbicacionGpsRepository;
import com.seguimientopromotor.service.UbicacionGpsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UbicacionGpsServiceImpl implements UbicacionGpsService {

    private final UbicacionGpsRepository ubicacionGpsRepository;

    public UbicacionGpsServiceImpl(UbicacionGpsRepository ubicacionGpsRepository) {
        this.ubicacionGpsRepository = ubicacionGpsRepository;
    }

    @Override
    public List<UbicacionGpsDto> findAll() {
        return ubicacionGpsRepository.findAll().stream().map(this::toDto).toList();
    }

    private UbicacionGpsDto toDto(UbicacionGps u) {
        String nombre = (u.getUsuario() != null) ? u.getUsuario().getNombre() : "Promotor";
        return new UbicacionGpsDto(u.getId(), nombre, u.getLatitud(), u.getLongitud(),
                u.getZona(), u.getFechaHora(), u.getEstadoSenal());
    }
}
