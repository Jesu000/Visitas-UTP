package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.request.AlumnoRequest;
import com.seguimientopromotor.dto.response.AlumnoDto;
import com.seguimientopromotor.model.Alumno;
import com.seguimientopromotor.repository.AlumnoRepository;
import com.seguimientopromotor.repository.UsuarioRepository;
import com.seguimientopromotor.service.AlumnoService;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class AlumnoServiceImpl implements AlumnoService {

    private final AlumnoRepository alumnoRepository;
    private final UsuarioRepository usuarioRepository;

    public AlumnoServiceImpl(AlumnoRepository alumnoRepository, UsuarioRepository usuarioRepository) {
        this.alumnoRepository = alumnoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public List<AlumnoDto> findAll(Sort sort) {
        return alumnoRepository.findAll(sort).stream().map(this::toDto).toList();
    }

    @Override
    public long count() {
        return alumnoRepository.count();
    }

    @Override
    public long countByNivelInteres(Alumno.NivelInteres nivelInteres) {
        return alumnoRepository.countByNivelInteres(nivelInteres);
    }

    @Override
    public AlumnoDto guardar(AlumnoRequest request, String promotorEmail) {
        Alumno a = new Alumno();
        a.setNombre(request.getNombre());
        a.setApellido(request.getApellido());
        a.setDni(request.getDni());
        a.setTelefono(request.getTelefono());
        a.setCorreo(request.getCorreo());
        a.setGradoSeccion(request.getGradoSeccion());
        a.setCarreraInteres(request.getCarreraInteres());
        a.setColegioNombre(request.getColegioNombre());
        // El promotor es siempre el usuario autenticado que registra al alumno
        a.setPromotor(usuarioRepository.findByEmail(promotorEmail).orElse(null));
        a.setFechaRegistro(LocalDate.now());
        a.setNivelInteres(request.getNivelInteres());
        return toDto(alumnoRepository.save(a));
    }

    @Override
    public void deleteById(Long id) {
        alumnoRepository.deleteById(id);
    }

    @Override
    public AlumnoDto actualizar(Long id, AlumnoRequest request) {
        return alumnoRepository.findById(id).map(a -> {
            a.setNombre(request.getNombre());
            a.setApellido(request.getApellido());
            a.setDni(request.getDni());
            a.setTelefono(request.getTelefono());
            a.setCorreo(request.getCorreo());
            a.setGradoSeccion(request.getGradoSeccion());
            a.setCarreraInteres(request.getCarreraInteres());
            a.setColegioNombre(request.getColegioNombre());
            a.setNivelInteres(request.getNivelInteres());
            // El promotor original se conserva: la edición no transfiere alumnos
            return toDto(alumnoRepository.save(a));
        }).orElseThrow(() -> new RuntimeException("Alumno no encontrado: " + id));
    }

    @Override
    public List<AlumnoDto> findByPromotor(String email, Sort sort) {
        return alumnoRepository.findByPromotor_Email(email, sort).stream().map(this::toDto).toList();
    }

    @Override
    public long countByPromotor(String email) {
        return alumnoRepository.countByPromotor_Email(email);
    }

    @Override
    public long countByNivelInteresAndPromotor(Alumno.NivelInteres nivel, String email) {
        return alumnoRepository.countByNivelInteresAndPromotor_Email(nivel, email);
    }

    private AlumnoDto toDto(Alumno a) {
        // El DTO sigue exponiendo el nombre del promotor como String para las vistas
        String promotorNombre = a.getPromotor() != null ? a.getPromotor().getNombre() : null;
        return new AlumnoDto(a.getId(), a.getNombre(), a.getApellido(), a.getDni(),
                a.getTelefono(), a.getCorreo(), a.getGradoSeccion(), a.getCarreraInteres(),
                a.getColegioNombre(), promotorNombre, a.getFechaRegistro(), a.getNivelInteres());
    }
}
