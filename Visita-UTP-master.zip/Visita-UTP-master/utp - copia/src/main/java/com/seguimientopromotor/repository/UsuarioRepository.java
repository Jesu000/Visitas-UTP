package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findFirstByNombre(String nombre);
    List<Usuario> findByEstado(Usuario.EstadoUsuario estado);
    List<Usuario> findByZonaContainingIgnoreCase(String zona);
    long countByEstado(Usuario.EstadoUsuario estado);
}
