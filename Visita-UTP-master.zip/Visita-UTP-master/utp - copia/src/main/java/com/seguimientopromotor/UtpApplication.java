package com.seguimientopromotor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.seguimientopromotor")
@EnableJpaRepositories(basePackages = "com.seguimientopromotor.repository")
@EntityScan(basePackages = "com.seguimientopromotor.model")
public class UtpApplication {
    public static void main(String[] args) {
        SpringApplication.run(UtpApplication.class, args);
    }
}