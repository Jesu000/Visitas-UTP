package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.request.UsuarioRequest;
import com.seguimientopromotor.dto.response.UsuarioDto;
import com.seguimientopromotor.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    List<UsuarioDto> findAll();
    long count();
    long countByEstado(Usuario.EstadoUsuario estado);
    List<UsuarioDto> findByEstado(Usuario.EstadoUsuario estado);
    Optional<UsuarioDto> findByEmail(String email);
    Optional<UsuarioDto> findById(Long id);
    /** @throws com.seguimientopromotor.exception.EmailDuplicadoException si el email ya existe */
    UsuarioDto crear(UsuarioRequest request);
    /** @throws com.seguimientopromotor.exception.EmailDuplicadoException si el email pertenece a otro usuario */
    UsuarioDto actualizar(Long id, UsuarioRequest request);
    /** @throws com.seguimientopromotor.exception.AutoEliminacionException si id corresponde a currentUserEmail */
    void deleteById(Long id, String currentUserEmail);
    void cambiarEstado(Long id, Usuario.EstadoUsuario nuevoEstado);
    boolean verificarPassword(String email, String passwordActual);
    void cambiarPassword(String email, String passwordNueva);
}
