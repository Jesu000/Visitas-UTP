package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "colegios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Colegio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String direccion;
    private String distrito;
    private String nombreContacto; // director o coordinador
    private String telefono;

    @Enumerated(EnumType.STRING)
    private EstadoColegio estado;

    public enum EstadoColegio {
        ACTIVO, INACTIVO
    }
}
