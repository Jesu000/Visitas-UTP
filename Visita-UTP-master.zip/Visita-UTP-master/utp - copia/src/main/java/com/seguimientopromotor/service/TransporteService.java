package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.request.TransporteRequest;
import com.seguimientopromotor.dto.response.TransporteDto;
import com.seguimientopromotor.dto.response.TransporteStatsDto;
import com.seguimientopromotor.model.Transporte;

import java.util.List;

public interface TransporteService {
    List<TransporteDto> findAll();
    TransporteStatsDto getStats();
    /** @throws com.seguimientopromotor.exception.PlacaDuplicadaException si la placa ya existe */
    TransporteDto guardar(TransporteRequest request);
    void deleteById(Long id);
    void cambiarEstado(Long id, Transporte.EstadoTransporte nuevoEstado);
}
