package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.Usuario;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioDto {
    private Long id;
    private String nombre;
    private String email;
    private String zona;
    private String rol;
    private Usuario.EstadoUsuario estado;
    private int visitas;
    private String codigo;
}
