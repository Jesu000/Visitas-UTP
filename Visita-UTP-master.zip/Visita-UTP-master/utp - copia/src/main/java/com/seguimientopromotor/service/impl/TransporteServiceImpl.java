package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.request.TransporteRequest;
import com.seguimientopromotor.dto.response.TransporteDto;
import com.seguimientopromotor.dto.response.TransporteStatsDto;
import com.seguimientopromotor.exception.PlacaDuplicadaException;
import com.seguimientopromotor.model.Transporte;
import com.seguimientopromotor.repository.TransporteRepository;
import com.seguimientopromotor.service.TransporteService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransporteServiceImpl implements TransporteService {

    private final TransporteRepository transporteRepository;

    public TransporteServiceImpl(TransporteRepository transporteRepository) {
        this.transporteRepository = transporteRepository;
    }

    @Override
    public List<TransporteDto> findAll() {
        return transporteRepository.findAll().stream().map(this::toDto).toList();
    }

    @Override
    public TransporteStatsDto getStats() {
        List<Transporte> entities = transporteRepository.findAll();
        List<TransporteDto> dtos = entities.stream().map(this::toDto).toList();
        long disponibles   = entities.stream().filter(t -> t.getEstado() == Transporte.EstadoTransporte.DISPONIBLE).count();
        long enRuta        = entities.stream().filter(t -> t.getEstado() == Transporte.EstadoTransporte.EN_RUTA).count();
        long mantenimiento = entities.stream().filter(t -> t.getEstado() == Transporte.EstadoTransporte.MANTENIMIENTO).count();
        return new TransporteStatsDto(dtos, disponibles, enRuta, mantenimiento);
    }

    @Override
    public TransporteDto guardar(TransporteRequest request) {
        String placa = request.getPlaca() != null ? request.getPlaca().trim().toUpperCase() : "";
        if (transporteRepository.findByPlacaIgnoreCase(placa).isPresent())
            throw new PlacaDuplicadaException(placa);

        Transporte t = new Transporte();
        t.setTipo(request.getTipo());
        t.setPlaca(placa);
        t.setConductor(request.getConductor());
        t.setCapacidad(request.getCapacidad() != null ? request.getCapacidad() : 0);
        t.setZonaCobertura(request.getZonaCobertura());
        t.setEmpleadoAsignado(blankToNull(request.getEmpleadoAsignado()));
        t.setEstado(Transporte.EstadoTransporte.DISPONIBLE);
        return toDto(transporteRepository.save(t));
    }

    @Override
    public void deleteById(Long id) {
        transporteRepository.deleteById(id);
    }

    @Override
    public void cambiarEstado(Long id, Transporte.EstadoTransporte nuevoEstado) {
        transporteRepository.findById(id).ifPresent(t -> {
            t.setEstado(nuevoEstado);
            transporteRepository.save(t);
        });
    }

    private String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    private TransporteDto toDto(Transporte t) {
        return new TransporteDto(t.getId(), t.getTipo(), t.getPlaca(), t.getConductor(),
                t.getCapacidad(), t.getZonaCobertura(), t.getEmpleadoAsignado(), t.getEstado());
    }
}
