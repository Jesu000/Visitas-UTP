package com.seguimientopromotor.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportesDto {
    private List<VisitaDto> visitas;
    private long realizadas;
    private long pendientes;
    private long canceladas;
    private long instituciones;
    private long evidencias;
    private long totalAlumnos;
    private List<ResumenPromotorDto> resumenPromotores;
}
