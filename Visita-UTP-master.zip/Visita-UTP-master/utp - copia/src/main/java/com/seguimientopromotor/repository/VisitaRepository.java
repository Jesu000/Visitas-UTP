package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.Visita;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface VisitaRepository extends JpaRepository<Visita, Long> {
    List<Visita> findByFechaProgramada(LocalDate fecha);
    List<Visita> findByEstado(Visita.EstadoVisita estado);
    long countByEstado(Visita.EstadoVisita estado);
    List<Visita> findTop3ByOrderByFechaProgramadaDesc();

    // Filtros por promotor a través de la relación (empleado.email)
    List<Visita> findByEmpleado_Email(String email, Sort sort);
    long countByEstadoAndEmpleado_Email(Visita.EstadoVisita estado, String email);
    List<Visita> findTop3ByEmpleado_EmailOrderByFechaProgramadaDesc(String email);
}
