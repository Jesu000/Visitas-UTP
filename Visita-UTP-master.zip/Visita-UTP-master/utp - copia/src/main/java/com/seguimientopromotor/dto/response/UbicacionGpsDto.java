package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.UbicacionGps;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UbicacionGpsDto {
    private Long id;
    private String usuarioNombre;
    private double latitud;
    private double longitud;
    private String zona;
    private LocalDateTime fechaHora;
    private UbicacionGps.EstadoSenal estadoSenal;
}
