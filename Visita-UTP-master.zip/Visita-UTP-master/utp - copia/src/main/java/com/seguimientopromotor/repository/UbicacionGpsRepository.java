package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.UbicacionGps;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UbicacionGpsRepository extends JpaRepository<UbicacionGps, Long> {
    List<UbicacionGps> findByEstadoSenal(UbicacionGps.EstadoSenal estadoSenal);
    Optional<UbicacionGps> findTopByUsuarioIdOrderByFechaHoraDesc(Long usuarioId);
    List<UbicacionGps> findByUsuarioIdOrderByFechaHoraDesc(Long usuarioId);
}
