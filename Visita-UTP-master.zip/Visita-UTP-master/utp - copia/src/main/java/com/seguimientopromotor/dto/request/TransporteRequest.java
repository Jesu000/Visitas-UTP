package com.seguimientopromotor.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransporteRequest {
    private String tipo;
    private String placa;
    private String conductor;
    private Integer capacidad;
    private String zonaCobertura;
    private String empleadoAsignado;
}
