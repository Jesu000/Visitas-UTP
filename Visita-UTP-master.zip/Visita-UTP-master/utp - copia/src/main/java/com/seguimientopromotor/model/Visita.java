package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "visitas")
@Data
@NoArgsConstructor
public class Visita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate fechaProgramada;
    private LocalTime horaEstimada;

    private String tipoVisita; // Convocatoria Presencial, Virtual, etc.
    private String colegioDestino;
    private String instrucciones;
    private String prioridad; // Normal, Alta, Urgente

    @Enumerated(EnumType.STRING)
    private EstadoVisita estado;

    private String evidenciaFoto;

    // Relación real con el promotor asignado (antes era texto suelto:
    // si cambiaba el nombre del usuario, las visitas quedaban con el nombre viejo)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario empleado;

    // Transporte asignado al momento del registro (para devolverlo cuando se complete)
    private Long transporteId;



    public enum EstadoVisita {
        REALIZADA, PENDIENTE, CANCELADA, VERIFICADA
    }
}
