package com.seguimientopromotor.dto.request;

import com.seguimientopromotor.model.Alumno;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AlumnoRequest {
    private String nombre;
    private String apellido;
    private String dni;
    private String telefono;
    private String correo;
    private String gradoSeccion;
    private String carreraInteres;
    private String colegioNombre;
    private String promotorNombre;
    private Alumno.NivelInteres nivelInteres;
}
