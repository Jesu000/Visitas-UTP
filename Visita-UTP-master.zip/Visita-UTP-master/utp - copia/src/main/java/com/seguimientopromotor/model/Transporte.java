package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "transportes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tipo; // Movilidad, Van, Bus
    private String placa;
    private String conductor;
    private int capacidad;
    private String zonaCobertura;
    private String empleadoAsignado; // promotor que usa la movilidad

    @Enumerated(EnumType.STRING)
    private EstadoTransporte estado;

    public enum EstadoTransporte {
        DISPONIBLE, EN_RUTA, MANTENIMIENTO
    }
}
