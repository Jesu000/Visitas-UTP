package com.seguimientopromotor.dto.response;

import com.seguimientopromotor.model.Alumno;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AlumnoDto {
    private Long id;
    private String nombre;
    private String apellido;
    private String dni;
    private String telefono;
    private String correo;
    private String gradoSeccion;
    private String carreraInteres;
    private String colegioNombre;
    private String promotorNombre;
    private LocalDate fechaRegistro;
    private Alumno.NivelInteres nivelInteres;
}
