package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.Colegio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ColegioRepository extends JpaRepository<Colegio, Long> {
    Optional<Colegio> findByNombre(String nombre);
    List<Colegio> findByEstado(Colegio.EstadoColegio estado);
    List<Colegio> findByDistritoContainingIgnoreCase(String distrito);
}
