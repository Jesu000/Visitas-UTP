package com.seguimientopromotor.controller;

import com.seguimientopromotor.dto.response.UsuarioDto;
import com.seguimientopromotor.service.UsuarioService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/**
 * Expone el usuario autenticado como "usuarioActual" en todas las vistas
 * (lo usa el topbar de fragments/layout.html).
 */
@ControllerAdvice
public class GlobalModelAttributes {

    private final UsuarioService usuarioService;

    public GlobalModelAttributes(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ModelAttribute("usuarioActual")
    public UsuarioDto usuarioActual(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) return null;
        return usuarioService.findByEmail(auth.getName()).orElse(null);
    }

    @ModelAttribute("esSupervisor")
    public boolean esSupervisor(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) return false;
        return auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_SUPERVISOR"));
    }
}
