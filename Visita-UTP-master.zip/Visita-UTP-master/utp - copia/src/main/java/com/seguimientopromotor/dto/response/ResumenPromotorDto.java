package com.seguimientopromotor.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResumenPromotorDto {
    private String promotor;
    private long visitas;
    private List<String> instituciones;
    private long evidencias;
}
