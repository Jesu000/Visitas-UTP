package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.Transporte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransporteRepository extends JpaRepository<Transporte, Long> {
    List<Transporte> findByEstado(Transporte.EstadoTransporte estado);
    long countByEstado(Transporte.EstadoTransporte estado);
    List<Transporte> findByZonaCoberturaContainingIgnoreCase(String zona);

    Optional<Transporte> findFirstByZonaCoberturaContainingIgnoreCaseAndEstado(
            String zona, Transporte.EstadoTransporte estado
    );

    Optional<Transporte> findByPlacaIgnoreCase(String placa);
}
