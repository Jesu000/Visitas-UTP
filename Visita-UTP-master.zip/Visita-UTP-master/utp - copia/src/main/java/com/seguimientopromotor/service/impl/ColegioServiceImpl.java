package com.seguimientopromotor.service.impl;

import com.seguimientopromotor.dto.request.ColegioRequest;
import com.seguimientopromotor.dto.response.ColegioDto;
import com.seguimientopromotor.model.Colegio;
import com.seguimientopromotor.repository.ColegioRepository;
import com.seguimientopromotor.service.ColegioService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ColegioServiceImpl implements ColegioService {

    private final ColegioRepository colegioRepository;

    public ColegioServiceImpl(ColegioRepository colegioRepository) {
        this.colegioRepository = colegioRepository;
    }

    @Override
    public List<ColegioDto> findAll() {
        return colegioRepository.findAll().stream().map(this::toDto).toList();
    }

    @Override
    public List<ColegioDto> findByEstado(Colegio.EstadoColegio estado) {
        return colegioRepository.findByEstado(estado).stream().map(this::toDto).toList();
    }

    @Override
    public ColegioDto guardar(ColegioRequest request) {
        Colegio c = new Colegio();
        c.setNombre(request.getNombre());
        c.setDireccion(request.getDireccion());
        c.setDistrito(request.getDistrito());
        c.setNombreContacto(request.getNombreContacto());
        c.setTelefono(request.getTelefono());
        c.setEstado(Colegio.EstadoColegio.ACTIVO);
        return toDto(colegioRepository.save(c));
    }

    @Override
    public void deleteById(Long id) {
        colegioRepository.deleteById(id);
    }

    private ColegioDto toDto(Colegio c) {
        return new ColegioDto(c.getId(), c.getNombre(), c.getDireccion(),
                c.getDistrito(), c.getNombreContacto(), c.getTelefono(), c.getEstado());
    }
}
