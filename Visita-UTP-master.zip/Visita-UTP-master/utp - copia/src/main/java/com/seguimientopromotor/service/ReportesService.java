package com.seguimientopromotor.service;

import com.seguimientopromotor.dto.response.ReportesDto;

public interface ReportesService {
    ReportesDto generarReporte();
}
