package com.seguimientopromotor.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String email;
    private String password;
    private String zona;
    private String rol; // PROMOTOR, SUPERVISOR, ADMIN

    @Enumerated(EnumType.STRING)
    private EstadoUsuario estado;

    private int visitas;
    private String codigo; // ej: E30314

    public enum EstadoUsuario {
        ACTIVO, INACTIVO, SUSPENDIDO
    }
}
