package com.seguimientopromotor.repository;

import com.seguimientopromotor.model.Alumno;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlumnoRepository extends JpaRepository<Alumno, Long> {
    List<Alumno> findByColegioNombre(String colegioNombre);
    long countByNivelInteres(Alumno.NivelInteres nivelInteres);

    // Filtros por promotor a través de la relación (promotor.email)
    List<Alumno> findByPromotor_Email(String email, Sort sort);
    long countByPromotor_Email(String email);
    long countByNivelInteresAndPromotor_Email(Alumno.NivelInteres nivel, String email);
}
